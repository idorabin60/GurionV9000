package bgu.spl.mics.application;

import bgu.spl.mics.application.objects.*;
import bgu.spl.mics.application.services.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * The main entry point for the GurionRock Pro Max Ultra Over 9000 simulation.
 * <p>
 * This class initializes the system and starts the simulation by setting up
 * services, objects, and configurations.
 * </p>
 */
public class GurionRockRunner {

    private static final List<LiDarWorkerTracker> lidarWorkers = new ArrayList<>();

    /**
     * The main method of the simulation.
     * This method sets up the necessary components, parses configuration files,
     * initializes services, and starts the simulation.
     *
     * @param args Command-line arguments. The first argument is expected to be the path to the configuration file.
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
        if (args.length < 1) {
            System.err.println("Usage: java Main <config-file-path>");
            return;
        }

        // Get the configuration file path from the arguments
        String configFilePath = args[0];

        try {
            // Parse configuration file
            JsonObject config = parseConfigFile(configFilePath);
            int tickTime = config.get("TickTime").getAsInt();
            int duration = config.get("Duration").getAsInt();
            System.out.println("TickTime: " + tickTime);
            String lidarDataPath = config.getAsJsonObject("LiDarWorkers").get("lidars_data_path").getAsString();
            System.out.println("Attempting to load LiDAR data from: " + lidarDataPath);

            // Initialize LiDAR DB
            LiDarDataBase lidarDataBase = loadLidarData(lidarDataPath);
            lidarDataBase.setCounterOfTrackedCloudPoints(LiDarDataBase.getInstance().getCloudPoints().size());
            System.out.println("LiDAR DB counter: " + LiDarDataBase.getInstance().getCounterOfTrackedCloudPoints());

            // Initialize LiDAR workers
            List<JsonObject> lidarConfigs = parseLidarWorkerConfigs(config);
            initializeLidarWorkers(lidarConfigs);

            // Initialize cameras
            List<Camera> cameras = initializeCameras(config);

            // Initialize GPSIMU
            GPSIMU gpsimu = initializeGPSIMU(configFilePath);

            System.out.println("LiDARs data:");
            lidarWorkers.forEach(worker -> System.out.println(worker.toString()));

            // Initialize microservices
            List<Thread> microserviceThreads = new ArrayList<>();
            cameras.forEach(camera -> microserviceThreads.add(new Thread(new CameraService(camera))));
            lidarWorkers.forEach(worker -> microserviceThreads.add(new Thread(new LiDarWorkerService(worker))));
            microserviceThreads.add(new Thread(new FusionSlamService(FusionSlam.getInstance(), cameras.size(), lidarWorkers.size())));
            microserviceThreads.add(new Thread(new PoseService(gpsimu)));
            microserviceThreads.add(new Thread(new TimeService(tickTime, duration)));

            // Start microservices
            SystemServicesCountDownLatch.init(cameras.size() + lidarWorkers.size() + 2);
            for (Thread thread : microserviceThreads) thread.start();
            for (Thread thread : microserviceThreads) thread.join();

            System.out.println("Simulation finished.");

            if (FusionSlam.getInstance().isThereIsError()) {
                ErrorOutput.getInstance().createErrorOutputFile();
            } else {
                createOutputJsonFile(FusionSlam.getInstance(), StatisticalFolder.getInstance());
                System.out.println("Output JSON file created: output_file.json");
            }
        } catch (IOException e) {
            handleError("Failed to load configuration file", e);
        } catch (RuntimeException | InterruptedException e) {
            handleError("Error during simulation", e);
        }
    }

    private static JsonObject parseConfigFile(String configFilePath) throws IOException {
        Gson gson = new Gson();
        JsonObject config = gson.fromJson(new FileReader(configFilePath), JsonObject.class);

        // Resolve base directory
        File configFile = new File(configFilePath);
        String baseDir = configFile.getParent();

        // Resolve paths
        resolvePath(config, "LiDarWorkers", "lidars_data_path", baseDir);
        resolvePath(config, "Cameras", "camera_datas_path", baseDir);
        resolvePath(config, null, "poseJsonFile", baseDir);

        return config;
    }

    private static void resolvePath(JsonObject config, String section, String key, String baseDir) {
        if (section != null && config.has(section)) {
            JsonObject sectionObject = config.getAsJsonObject(section);
            if (sectionObject.has(key)) {
                String relativePath = sectionObject.get(key).getAsString();
                sectionObject.addProperty(key, new File(baseDir, relativePath).getAbsolutePath());
            }
        } else if (config.has(key)) {
            String relativePath = config.get(key).getAsString();
            config.addProperty(key, new File(baseDir, relativePath).getAbsolutePath());
        }
    }

    private static LiDarDataBase loadLidarData(String lidarDataPath) {
        return LiDarDataBase.getInstance(lidarDataPath);
    }

    private static List<JsonObject> parseLidarWorkerConfigs(JsonObject config) {
        Gson gson = new Gson();
        Type lidarConfigListType = new TypeToken<List<JsonObject>>() {}.getType();
        return gson.fromJson(config.getAsJsonObject("LiDarWorkers").get("LidarConfigurations"), lidarConfigListType);
    }

    private static void initializeLidarWorkers(List<JsonObject> lidarConfigs) {
        lidarConfigs.forEach(config -> {
            int id = config.get("id").getAsInt();
            int frequency = config.get("frequency").getAsInt();
            lidarWorkers.add(new LiDarWorkerTracker(id, frequency));
        });
    }

    private static List<Camera> initializeCameras(JsonObject config) {
        String cameraDataPath = config.getAsJsonObject("Cameras").get("camera_datas_path").getAsString();
        System.out.println("Resolved camera data path: " + cameraDataPath); // Debug print

        // Initialize cameras from configuration
        List<Camera> cameras = CameraDataUpdater.initializeCamerasFromConfig(cameraDataPath);

        // Update cameras with the correct data file
        CameraDataUpdater.updateCamerasFromJson(cameras, cameraDataPath);

        return cameras;
    }

    private static GPSIMU initializeGPSIMU(String configFilePath) {
        GPSIMUDataBase gpsimuDataBase = GPSIMUDataBase.getInstance();
        gpsimuDataBase.initialize(configFilePath);
        return gpsimuDataBase.getGPSIMU();
    }

    private static void handleError(String message, Exception e) {
        System.err.println(message + ": " + e.getMessage());
        e.printStackTrace();
    }

    private static void createOutputJsonFile(FusionSlam fusionSlam, StatisticalFolder statisticalFolder) throws IOException {
        Gson gson = new Gson();
        JsonObject outputJson = new JsonObject();

        outputJson.addProperty("systemRuntime", statisticalFolder.getSystemRuntime());
        outputJson.addProperty("numDetectedObjects", statisticalFolder.getNumDetectedObjects());
        outputJson.addProperty("numTrackedObjects", statisticalFolder.getNumTrackedObjects());
        outputJson.addProperty("numLandmarks", statisticalFolder.getNumLandmarks());

        JsonObject landmarksJson = new JsonObject();
        fusionSlam.getLandmarks().forEach(landmark -> {
            JsonObject landmarkJson = new JsonObject();
            landmarkJson.addProperty("id", landmark.getId());
            landmarkJson.addProperty("description", landmark.getDescription());
            Type listType = new TypeToken<List<JsonObject>>() {}.getType();
            landmarkJson.add("coordinates", gson.toJsonTree(landmark.getCoordinates(), listType));
            landmarksJson.add(landmark.getId(), landmarkJson);
        });
        outputJson.add("landMarks", landmarksJson);

        try (FileWriter writer = new FileWriter("output_file.json")) {
            gson.toJson(outputJson, writer);
        }
    }
}
